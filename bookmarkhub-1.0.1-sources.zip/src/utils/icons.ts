import {
    AiOutlineCloudUpload, AiOutlineCloudDownload,
    AiOutlineCloudSync, AiOutlineSetting, AiOutlineClear,
    AiOutlineBook, AiOutlineInfoCircle,AiOutlineGithub
} from 'react-icons/ai'

export default {
    AiOutlineBook,
    AiOutlineCloudUpload,
    AiOutlineCloudDownload,
    AiOutlineCloudSync,
    AiOutlineSetting,
    AiOutlineClear,
    AiOutlineInfoCircle,
    AiOutlineGithub,
}